
# Kirsten Rieger · Online Portfolio

Willkommen auf meiner persönlichen Portfolio-Seite.

Hier finden Sie:
- Mein Motivationsschreiben
- Meinen aktuellen Lebenslauf
- Ausgewählte Arbeitszeugnisse
- (Optional) Projektbeispiele / Mini-Case

Diese Seite wurde erstellt mit [GitHub Pages](https://pages.github.com) und dient der Unterstützung meiner Bewerbungen im Bereich Transformation, Digitalisierung und Change Management.

**Website:** [https://kirstenrieger.github.io](https://kirstenrieger.github.io)
